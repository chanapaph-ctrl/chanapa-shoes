---
name: Sole Studio Luxe Street
colors:
  surface: '#fbf8ff'
  surface-dim: '#dad9e3'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2fd'
  surface-container: '#eeedf7'
  surface-container-high: '#e8e7f1'
  surface-container-highest: '#e3e1ec'
  on-surface: '#1a1b22'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3038'
  inverse-on-surface: '#f1effa'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#bc000a'
  on-secondary: '#ffffff'
  secondary-container: '#e2241f'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#161e00'
  on-tertiary-container: '#718e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#ffdad5'
  secondary-fixed-dim: '#ffb4aa'
  on-secondary-fixed: '#410001'
  on-secondary-fixed-variant: '#930005'
  tertiary-fixed: '#c3f400'
  tertiary-fixed-dim: '#abd600'
  on-tertiary-fixed: '#161e00'
  on-tertiary-fixed-variant: '#3c4d00'
  background: '#fbf8ff'
  on-background: '#1a1b22'
  surface-variant: '#e3e1ec'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-caps-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-caps-sm:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.1em
  price-display:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  touch-min: 48px
  edge-mobile: 16px
  edge-tablet: 24px
  edge-desktop: 40px
  gutter-mobile: 12px
  gutter-tablet: 16px
  gutter-desktop: 24px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  stack-xl: 40px
  stack-2xl: 64px
---

## Brand & Style

This design system blends high-heat urban streetwear culture with the disciplined refinement of contemporary gallery luxury. Engineered mobile-first for sneaker collectors and style-forward tastemakers, the aesthetic mirrors physical flagship boutiques: hyper-curated, stark, confident, and editorial.

The emotional tone balances adrenaline and exclusivity—the anticipation of a limited drop paired with the pristine certainty of high-end commerce. Visual expression leans on deep contrast, bold kinetic typography, oversized product photography set against clean isolation fields, and razor-sharp accents signaling urgency and status without clutter.

## Colors

The foundation is built on deep carbon black (`#111111`) and crisp stark white (`#FFFFFF`), anchored by architectural warm neutral tiers (`#F5F5F7`, `#E5E5EA`, `#D1D1D6`). 

- **Primary (`#111111`):** Grounds primary interactions, heavy title typography, structural navigation, and hero UI elements.
- **Secondary (`#FF3B30` - Electric Crimson):** Reserved for high-voltage interactions: exclusive release flags, limited stock timers, active cart badges, and critical action triggers.
- **Tertiary (`#CCFF00` - Neon Volt):** The subcultural hype accent. Used sparingly for drop tickers, member-exclusive tags, and energetic interactive confirmations.
- **Neutrals:** `#F5F5F7` acts as the primary canvas for product studio cutouts, isolating silhouettes cleanly; `#E5E5EA` defines hair-thin borders and divider rules; `#71717A` delivers secondary meta-information and specs.

In dark mode or high-heat editorial contexts, the hierarchy reverses cleanly to an absolute `#0A0A0A` base with `#18181B` surface elevations, maintaining Electric Crimson and Volt vibrancy at full saturation.

## Typography

Typography establishes tension between technical brutalism and clinical fashion editorial.

- **Headline & Display Font (Space Grotesk):** Provides mechanical geometry, idiosyncratic ink-traps, and street-culture edge. Used for drop names, brand collabs, big numbers, release tickers, and badges.
- **Body Font (Inter):** Supplies transparent, neutral, and ergonomic readability across product descriptions, sizing guides, order manifests, and checkout flows.
- **Label System:** All category markers, release status tags, and technical specs utilize uppercase Space Grotesk tracking (`+0.08em` to `+0.1em`) to mimic physical industrial labeling and limited-edition shoebox packaging.

## Layout & Spacing

The layout is strictly mobile-first, deploying an adaptable fluid column architecture:
- **Mobile (<768px):** 4-column fluid layout with a mandatory `16px` screen edge margin and `12px` gutters. Single-column or dual-column asymmetric product grids. All interactive touch surfaces strictly maintain a minimum height and width of `48px` (`touch-min`).
- **Tablet (768px - 1024px):** 8-column layout with `24px` margins and `16px` gutters. Product grids transition to 3-column matrices with sticky contextual filter bars.
- **Desktop (>1024px):** 12-column layout maxing out at `1440px` centered canvas, `40px` margins, and `24px` gutters. Product detail views lock to a split-screen viewport: an unconstrained multi-angle photo gallery on the left, locked checkout and sizing panel on the right.

Vertical spacing obeys an 8pt baseline rhythm, using aggressive macro-spacing (`64px+`) between editorial chapters to create gallery-like pauses, counterbalanced by compact, disciplined spacing within transaction modules.

## Elevation & Depth

Visual hierarchy rejects muddy, generic drop shadows in favor of tonal surface containment and precision ambient contact shadows.

- **Base Layer (Level 0):** Pure `#FFFFFF` for primary screen backgrounds or `#F5F5F7` for secondary carousel track modules.
- **Product Tiles & Cards (Level 1):** Flat `#FFFFFF` floating over a `#F5F5F7` base with an ultra-subtle contact shadow: `0 4px 20px -2px rgba(17, 17, 17, 0.04)` combined with an interior 1px hairline border in `rgba(17, 17, 17, 0.06)`.
- **Floating Modals, Quick-Buy & Bottom Sheets (Level 2):** Elevated interactive planes utilize a diffused lift shadow: `0 16px 40px -8px rgba(17, 17, 17, 0.12)`, punctuated by a crisp top rim border.
- **Sticky Bars & Header Scrims:** Translucent frosted glass effect using `rgba(255, 255, 255, 0.88)` with `backdrop-filter: blur(16px)` and a single bottom border of `#E5E5EA`.

## Shapes

The design system employs a `Rounded` (Level 2) shape language, balancing soft handheld ergonomics with sharp urban industrialism:

- **Product Cards & Structural Containers:** `16px` (`rounded-lg`) corner radii keep footwear photography modern, friendly, and contained.
- **Buttons, Floating Trays & Pill Selectors:** Sizing chips, tag pills, and secondary tags use `8px` (`rounded`) for structured compactness, while sticky bottom call-to-actions utilize `12px` to fill the palm comfortably.
- **Status Badges:** Small micro-badges use tight `4px` or `6px` radii, projecting an authoritative, seal-of-authenticity stamp profile.

## Components

### Buttons
- **Primary Action (Buy / Pre-Order):** Solid `#111111` fill, `#FFFFFF` Space Grotesk 14px bold uppercase text, height `52px`, `12px` radius. Active state: transforms to 96% scale with haptic feedback feel.
- **Drop / High Heat Action:** Solid `#FF3B30` fill with white text for imminent launches, countdown locks, or high-priority calls.
- **Secondary / Size Selector Button:** `#F5F5F7` background, `#111111` label, border `1px solid transparent`. Active/Selected: `#111111` fill, `#FFFFFF` text. Disabled (Sold Out): slashed strike-through with `opacity-40` and muted diagonal line.

### Badges & Drop Tickers
- **New Release:** Solid `#111111` background, `#FFFFFF` text, `label-caps-sm`, `padding: 4px 8px`.
- **Exclusive Drop:** Electric Crimson (`#FF3B30`) background, `#FFFFFF` text.
- **Member / Hype Level:** Neon Volt (`#CCFF00`) background, `#111111` text, high visibility.
- **Stock Ticker:** Subtle pill with a pulsing 6px circular dot (`#FF3B30`) alongside text like `"ONLY 3 PAIRS LEFT"`.

### Product Cards
- Contained within `#FFFFFF` or `#F9F9FB` surface with `16px` border-radius.
- Top row: left-aligned brand meta (`label-caps-sm`), right-aligned favorite icon (44px tap zone).
- Center: 1:1 or 4:5 aspect ratio sneaker cutout, hovered or tilted on touch.
- Bottom info lockup: Model name in `headline-sm`, subtitle/colorway in `body-sm`, followed immediately by bold `price-display`. Quick-add size drawer triggers from bottom sheet.

### Inputs & Sizing Chips
- **Search & Text Input:** Height `48px`, `#F5F5F7` fill, no border in default state, transitioning to `1.5px solid #111111` upon focus. Left-aligned technical icon, clear button right-aligned.
- **Size Grid:** Modular multi-column matrix of `48px x 48px` squares, displaying US/UK sizing with instant stock feedback (instantly grayed out with diagonal hash if unfulfilled).

### Navigation & Bottom Action Bar
- **Mobile App Bar:** Floating sticky bottom pill or edge-to-edge docked bar containing quick bag status, instant purchase slide-to-lock button, and persistent price summary.
- **Tabs & Filters:** Horizontally scrolling pill-list with auto-snap, zero scrollbar indicator, and active indicator transitioning via spring physics.